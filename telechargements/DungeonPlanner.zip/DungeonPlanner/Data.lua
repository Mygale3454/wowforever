-- Dungeon Planner : listes (guilde, activités). Modifie ce fichier pour ajouter un donjon ou une zone.
local ADDON, ns = ...

-- Nom exact de la guilde autorisée. L'addon ne fonctionne que pour ses membres.
-- Mets "" pour l'ouvrir à n'importe quelle guilde.
ns.GUILD = "Horadrim Legacy"

-- id court (ne jamais le changer une fois utilisé), nom affiché, niveaux
ns.ACTIVITES = {
  { cat = "Donjons", list = {
    { "ragefeu",   "Gouffre de Ragefeu", "13-18" },
    { "thanes",    "La Salle des Thanes", "13-18" },
    { "lordaeron", "Ruines de Lordaeron", "15-20" },
    { "mortemines","Les Mortemines", "15-22" },
    { "lamentations","Cavernes des lamentations", "17-24" },
    { "ombrecroc", "Donjon d'Ombrecroc", "20-26" },
    { "brassenoire","Profondeurs de Brassenoire", "22-28" },
    { "paluns",    "Site de fouilles des Paluns", "24-29" },
    { "prison",    "La Prison", "25-29" },
    { "dalaran",   "Cité de Dalaran", "28-33" },
    { "gnomeregan","Gnomeregan", "29-38" },
    { "kraal",     "Kraal de Tranchebauge", "29-38" },
    { "me-cim",    "Monastère écarlate : Cimetière", "30-37" },
    { "me-bib",    "Monastère écarlate : Bibliothèque", "33-40" },
    { "me-arm",    "Monastère écarlate : Armurerie", "36-43" },
    { "me-cat",    "Monastère écarlate : Cathédrale", "38-46" },
    { "englo",     "La Cité engloutie", "35-40" },
    { "uldaman",   "Uldaman", "36-45" },
    { "souilles",  "Souilles de Tranchebauge", "37-46" },
    { "krol",      "Bastion de Krol'dok", "40-45" },
    { "zf",        "Zul'Farrak", "40-47" },
    { "maraudon",  "Maraudon", "45-51" },
    { "alcaz",     "Prison d'Alcaz", "48-53" },
    { "temple",    "Temple englouti", "50-55" },
    { "brd",       "Profondeurs de Rochenoire", "52-60" },
    { "noiregueules","Repaire des Noiregueules", "55-60" },
    { "lbrs",      "Pic Rochenoire inférieur", "57-60" },
    { "faconneur", "Terrasse du Façonneur", "58-60" },
    { "ht",        "Hache-Tripes", "58-60" },
    { "strat",     "Stratholme", "58-60" },
    { "scholo",    "Scholomance", "58-60" },
    { "ubrs",      "Pic Rochenoire supérieur", "60" },
  }},
  { cat = "Quêtes élites", list = {
    { "qe-penombre",  "Quêtes élites : Bois de la Pénombre", "25-30" },
    { "qe-paluns",    "Quêtes élites : Les Paluns", "25-30" },
    { "qe-hautebrande","Quêtes élites : Contreforts de Hautebrande", "30-35" },
    { "qe-arathi",    "Quêtes élites : Hautes-terres d'Arathi", "35-40" },
    { "qe-alterac",   "Quêtes élites : Montagnes d'Alterac", "35-40" },
    { "qe-strangle",  "Quêtes élites : Vallée de Strangleronce", "35-45" },
    { "qe-ingrates",  "Quêtes élites : Terres ingrates", "40-45" },
    { "qe-chagrins",  "Quêtes élites : Marais des Chagrins", "40-45" },
    { "qe-feralas",   "Quêtes élites : Féralas", "45-50" },
    { "qe-hinter",    "Quêtes élites : Les Hinterlands", "45-50" },
    { "qe-gangrebois","Quêtes élites : Gangrebois", "50-55" },
    { "qe-steppes",   "Quêtes élites : Steppes ardentes", "55-60" },
    { "qe-maleterres","Quêtes élites : Maleterres", "55-60" },
  }},
  { cat = "Autre", list = {
    { "autre",     "Autre (préciser dans la note)", "" },
  }},
}

ns.ACT = {}
for _, c in ipairs(ns.ACTIVITES) do
  for _, a in ipairs(c.list) do ns.ACT[a[1]] = { name = a[2], lvl = a[3], cat = c.cat } end
end
function ns.ActName(id)
  local a = id and ns.ACT[id]
  return a and a.name or (id and ("? " .. id) or "Toutes les activités")
end
