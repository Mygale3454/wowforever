-- Dungeon Planner : données et échange entre membres de la guilde (canal caché des addons de guilde).
local ADDON, ns = ...

local PREFIX = "DPlan1"
local SEP = "\t"

ns.relayedAt = {}      -- clé -> GetTime() du dernier relais reçu (pour ne pas relayer deux fois)

-- ---------- Outils ----------
function ns.Today(offset)
  return date("%Y-%m-%d", time() + (offset or 0) * 86400)
end

local function realm()
  local r = GetNormalizedRealmName and GetNormalizedRealmName()
  if r and r ~= "" then return r end
  return nil
end

function ns.Norm(name)
  if not name or name == "" then return nil end
  if not name:find("-", 1, true) then
    local r = realm()
    if r then name = name .. "-" .. r end
  end
  return name
end

function ns.MyName()
  local n, r = UnitFullName("player")
  if not r or r == "" then r = realm() end
  if r then return n .. "-" .. r end
  return n
end

local function split(s)
  local t = {}
  for field in (s .. SEP):gmatch("(.-)" .. SEP) do t[#t + 1] = field end
  return t
end

local function clean(s)
  s = tostring(s or "")
  s = s:gsub("[\t|\r\n]", " ")
  return s
end

local function keyOf(e) return e.p .. "#" .. e.id end
ns.KeyOf = keyOf

-- ---------- Base locale ----------
function ns.InitDB()
  DungeonPlannerDB = DungeonPlannerDB or {}
  local db = DungeonPlannerDB
  db.entries = db.entries or {}
  db.nextId = db.nextId or 0
  db.last = db.last or {}          -- derniers choix du formulaire
  ns.db = db
  ns.Purge()
end

function ns.Purge()
  local today = ns.Today()
  for k, e in pairs(ns.db.entries) do
    if type(e) ~= "table" or not e.d or e.d < today then ns.db.entries[k] = nil end
  end
end

-- Les personnages dont le nom contient « Araneae » (Mygale) passent outre la restriction de guilde.
function ns.Bypass()
  local n = UnitName("player") or ""
  return n:lower():find("araneae", 1, true) ~= nil
end

function ns.Allowed()
  if ns.Bypass() then return true end
  if not IsInGuild() then return false end
  if not ns.GUILD or ns.GUILD == "" then return true end
  local g = GetGuildInfo("player")
  return g == ns.GUILD
end

-- Ajoute ou remplace une inscription reçue ; renvoie true si quelque chose a changé.
function ns.Merge(e)
  if e.d < ns.Today() then return false end
  local k = keyOf(e)
  local cur = ns.db.entries[k]
  if cur and (cur.t or 0) >= (e.t or 0) then return false end
  ns.db.entries[k] = e
  return true
end

-- Inscriptions visibles (non retirées), filtrées par activité et jour (nil = tout).
local ROLEORDER = { TANK = 1, HEAL = 2, DPS = 3 }
function ns.List(act, day, onlyMine)
  local out, today = {}, ns.Today()
  for _, e in pairs(ns.db.entries) do
    if not e.x and e.d >= today and (not act or e.a == act) and (not day or e.d == day)
       and (not onlyMine or e.p == ns.me) then
      out[#out + 1] = e
    end
  end
  table.sort(out, function(a, b)
    if a.d ~= b.d then return a.d < b.d end
    if a.h1 ~= b.h1 then return a.h1 < b.h1 end
    local ra, rb = ROLEORDER[a.r] or 9, ROLEORDER[b.r] or 9
    if ra ~= rb then return ra < rb end
    return a.p < b.p
  end)
  return out
end

-- ---------- Messages ----------
local function encode(e)
  return table.concat({ e.id, e.c or "", e.l or 0, e.r or "", e.d, e.h1, e.h2, e.a or "", e.t, e.x and 1 or 0, clean(e.n) }, SEP)
end

local function decode(f, i, p)
  local e = {
    p = p, id = tonumber(f[i]), c = f[i + 1], l = tonumber(f[i + 2]), r = f[i + 3], d = f[i + 4],
    h1 = tonumber(f[i + 5]), h2 = tonumber(f[i + 6]), a = f[i + 7], t = tonumber(f[i + 8]),
    x = (f[i + 9] == "1") or nil, n = f[i + 10] or "",
  }
  if not (p and e.id and e.l and e.h1 and e.h2 and e.t and e.d and e.d:match("^%d%d%d%d%-%d%d%-%d%d$")) then return nil end
  return e
end

-- File d'envoi : un message par seconde (limite des messages d'addon).
local queue, ticker = {}, nil
local function pump()
  local m = queue[1]
  if not m then
    if ticker then ticker:Cancel(); ticker = nil end
    return
  end
  if m.relayKey then
    local seen = ns.relayedAt[m.relayKey]
    if seen and seen > m.since then table.remove(queue, 1); return pump() end
  end
  local ok = C_ChatInfo.SendAddonMessage(PREFIX, m.msg, "GUILD")
  local res = Enum and Enum.SendAddonMessageResult
  if ok == false or (type(ok) == "number" and res and res.Success and ok ~= res.Success) then return end -- on réessaie au prochain tour
  table.remove(queue, 1)
end

local function enqueue(msg, relayKey, since)
  if not ns.Allowed() or not IsInGuild() then return end
  queue[#queue + 1] = { msg = msg, relayKey = relayKey, since = since }
  if not ticker then
    ticker = C_Timer.NewTicker(1.0, pump)
    pump()
  end
end

local function sendOwn()
  local today = ns.Today()
  for _, e in pairs(ns.db.entries) do
    if e.p == ns.me and e.d >= today then enqueue("E" .. SEP .. encode(e)) end
  end
end

local function onlineSet()
  local s = {}
  local n = GetNumGuildMembers and GetNumGuildMembers() or 0
  for i = 1, n do
    local name, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
    if name and online then s[ns.Norm(name)] = true end
  end
  return s
end

-- Un membre vient de se connecter et demande les dispos : on envoie les nôtres, puis
-- (après un délai au hasard) celles des membres hors ligne qu'on connaît, sauf si un autre l'a déjà fait.
local function onRequest(from)
  sendOwn()
  local since = GetTime()
  C_Timer.After(2 + math.random() * 6, function()
    local online = onlineSet()
    local today = ns.Today()
    for k, e in pairs(ns.db.entries) do
      if e.p ~= ns.me and e.p ~= from and not online[e.p] and e.d >= today then
        enqueue("R" .. SEP .. e.p .. SEP .. encode(e), k, since)
      end
    end
  end)
end

local function onMessage(prefix, msg, channel, sender)
  if prefix ~= PREFIX or channel ~= "GUILD" or not ns.db then return end
  sender = ns.Norm(sender)
  if not sender or sender == ns.me then return end
  local f = split(msg)
  local kind, e = f[1], nil
  if kind == "E" then
    e = decode(f, 2, sender)
  elseif kind == "R" then
    local p = ns.Norm(f[2])
    if p == ns.me then return end            -- personne ne parle à notre place
    e = decode(f, 3, p)
    if e then ns.relayedAt[keyOf(e)] = GetTime() end
  elseif kind == "Q" then
    onRequest(sender)
    return
  end
  if e and ns.Merge(e) then ns.Refresh() end
end

-- ---------- Actions du joueur ----------
function ns.Publish(e)
  ns.db.nextId = (ns.db.nextId % 99999) + 1
  e.id = e.id or ns.db.nextId
  e.p = ns.me
  e.t = GetServerTime()
  ns.db.entries[keyOf(e)] = e
  enqueue("E" .. SEP .. encode(e))
  ns.Refresh()
end

function ns.Remove(e)
  e.x = true
  e.t = GetServerTime()
  enqueue("E" .. SEP .. encode(e))
  ns.Refresh()
end

function ns.Refresh()
  if ns.UIUpdate then ns.UIUpdate() end
end

-- ---------- Démarrage ----------
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("PLAYER_LEVEL_UP")
ev:RegisterEvent("PLAYER_GUILD_UPDATE")
ev:SetScript("OnEvent", function(_, event, ...)
  if event == "PLAYER_LOGIN" then
    ns.InitDB()
    ns.me = ns.MyName()
    C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
    if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end
    C_Timer.After(8, function()
      if ns.Allowed() then
        enqueue("Q")
        sendOwn()
      end
      print("|cffb48cffDungeon Planner|r |cffff9900(bêta)|r : tape |cffffd100/dispo|r pour voir qui est dispo dans la guilde.")
    end)
  elseif event == "CHAT_MSG_ADDON" then
    onMessage(...)
  elseif event == "PLAYER_LEVEL_UP" then
    local lvl = ...
    for _, e in pairs(ns.db.entries) do
      if e.p == ns.me and not e.x then e.l = lvl; ns.Publish(e) end
    end
  elseif event == "PLAYER_GUILD_UPDATE" then
    ns.Refresh()
  end
end)

SLASH_DUNGEONPLANNER1 = "/dispo"
SLASH_DUNGEONPLANNER2 = "/planner"
SlashCmdList.DUNGEONPLANNER = function() if ns.Toggle then ns.Toggle() end end
