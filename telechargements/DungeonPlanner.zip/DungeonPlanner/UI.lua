-- Dungeon Planner : fenêtre (onglets « Qui est dispo ? » et « M'inscrire »).
local ADDON, ns = ...

local JOURS = { "Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi" }
local ROLES = { { "TANK", "Tank", "4fa3ff" }, { "HEAL", "Soins", "5bd35b" }, { "DPS", "Dégâts", "ff6b5b" } }
local ROLE = {}
for _, r in ipairs(ROLES) do ROLE[r[1]] = r end

local function roleText(k)
  local r = ROLE[k]
  return r and ("|cff" .. r[3] .. r[2] .. "|r") or "?"
end

local function hm(m)
  m = m or 0
  return string.format("%02d:%02d", math.floor(m / 60) % 24, m % 60)
end

local function dayLabel(d)
  if d == ns.Today() then return "Aujourd'hui" end
  if d == ns.Today(1) then return "Demain" end
  local y, mo, dd = d:match("(%d+)-(%d+)-(%d+)")
  if not y then return d end
  local t = time({ year = tonumber(y), month = tonumber(mo), day = tonumber(dd), hour = 12 })
  return JOURS[tonumber(date("%w", t)) + 1] .. " " .. tonumber(dd)
end

local function classColor(cls)
  local c = (C_ClassColor and cls and C_ClassColor.GetClassColor(cls)) or (RAID_CLASS_COLORS and RAID_CLASS_COLORS[cls or ""])
  if c then return c.r, c.g, c.b end
  return 1, 1, 1
end

local function className(cls)
  return (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[cls or ""]) or cls or "?"
end

local function short(name)
  if Ambiguate then return Ambiguate(name, "guild") end
  return (name:gsub("%-.*$", ""))
end

local function whisper(name)
  if ChatFrame_SendTell then ChatFrame_SendTell(name)
  elseif ChatFrameUtil and ChatFrameUtil.SendTell then ChatFrameUtil.SendTell(name) end
end

local function invite(name)
  if C_PartyInfo and C_PartyInfo.InviteUnit then C_PartyInfo.InviteUnit(name)
  elseif InviteUnit then InviteUnit(name) end
end

-- ---------- État ----------
local view = { act = nil, day = nil }        -- filtres de l'onglet « Qui est dispo ? »
local form = {}                              -- formulaire « M'inscrire »

local function dropdown(parent, width, gen, label)
  local dd = CreateFrame("DropdownButton", nil, parent, "WowStyle1DropdownTemplate")
  dd:SetWidth(width)
  dd:SetupMenu(gen)
  if label then dd:SetSelectionText(label) end
  return dd
end

local function activityMenu(root, isSel, setSel, withAll)
  if withAll then
    root:CreateRadio("Toutes les activités", function() return isSel(nil) end, function() setSel(nil) end)
  end
  for _, c in ipairs(ns.ACTIVITES) do
    local sub = root:CreateButton(c.cat)
    if #c.list > 14 then sub:SetScrollMode(420) end
    for _, a in ipairs(c.list) do
      local id = a[1]
      local txt = a[3] ~= "" and (a[2] .. "  |cff999999" .. a[3] .. "|r") or a[2]
      sub:CreateRadio(txt, function() return isSel(id) end, function() setSel(id) end)
    end
  end
end

-- ---------- Fenêtre ----------
local F, P1, P2, update

local function build()
  F = CreateFrame("Frame", "DungeonPlannerFrame", UIParent, "BasicFrameTemplateWithInset")
  F:SetSize(660, 480)
  F:SetPoint("CENTER")
  F:SetFrameStrata("HIGH")
  F:SetMovable(true); F:EnableMouse(true); F:SetClampedToScreen(true)
  F:RegisterForDrag("LeftButton")
  F:SetScript("OnDragStart", F.StartMoving)
  F:SetScript("OnDragStop", F.StopMovingOrSizing)
  F:Hide()
  tinsert(UISpecialFrames, "DungeonPlannerFrame")
  local title = F.TitleText or F:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  if not F.TitleText then title:SetPoint("TOP", 0, -5) end
  title:SetText("Dungeon Planner |cffff9900(bêta)|r – " .. (ns.GUILD ~= "" and ns.GUILD or "Guilde"))

  F.warn = F:CreateFontString(nil, "OVERLAY", "GameFontRedSmall")
  F.warn:SetPoint("BOTTOM", 0, 12)

  P1 = CreateFrame("Frame", nil, F); P1:SetPoint("TOPLEFT", 12, -62); P1:SetPoint("BOTTOMRIGHT", -12, 30)
  P2 = CreateFrame("Frame", nil, F); P2:SetPoint("TOPLEFT", 12, -62); P2:SetPoint("BOTTOMRIGHT", -12, 30)

  local function tab(text, x, panel, other)
    local b = CreateFrame("Button", nil, F, "UIPanelButtonTemplate")
    b:SetSize(150, 24); b:SetPoint("TOPLEFT", x, -30); b:SetText(text)
    b:SetScript("OnClick", function() panel:Show(); other:Hide(); update() end)
    return b
  end
  tab("Qui est dispo ?", 14, P1, P2)
  tab("M'inscrire", 170, P2, P1)
  P2:Hide()

  -- ===== Onglet 1 : qui est dispo ? =====
  local ddAct = dropdown(P1, 260, function(_, root)
    activityMenu(root, function(id) return view.act == id end, function(id) view.act = id; C_Timer.After(0, update) end, true)
  end, function() return ns.ActName(view.act) end)
  ddAct:SetPoint("TOPLEFT", 4, 0)

  local ddDay = dropdown(P1, 170, function(_, root)
    root:CreateRadio("Toute la semaine", function() return view.day == nil end, function() view.day = nil; C_Timer.After(0, update) end)
    for i = 0, 6 do
      local d = ns.Today(i)
      root:CreateRadio(dayLabel(d), function() return view.day == d end, function() view.day = d; C_Timer.After(0, update) end)
    end
  end, function() return view.day and dayLabel(view.day) or "Toute la semaine" end)
  ddDay:SetPoint("LEFT", ddAct, "RIGHT", 10, 0)

  P1.sum = P1:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  P1.sum:SetPoint("TOPLEFT", 6, -34); P1.sum:SetJustifyH("LEFT")

  local COLS = { { "Joueur", 0 }, { "Niv.", 120 }, { "Rôle", 152 }, { "Jour", 205 }, { "Horaires", 295 }, { "Activité / note", 385 } }
  for _, c in ipairs(COLS) do
    local h = P1:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    h:SetPoint("TOPLEFT", 8 + c[2], -58); h:SetText(c[1])
  end

  local sf = CreateFrame("ScrollFrame", "DungeonPlannerScroll", P1, "UIPanelScrollFrameTemplate")
  sf:SetPoint("TOPLEFT", 0, -72); sf:SetPoint("BOTTOMRIGHT", -26, 0)
  local child = CreateFrame("Frame", nil, sf); child:SetSize(600, 10); sf:SetScrollChild(child)
  P1.child, P1.rows = child, {}

  P1.empty = P1:CreateFontString(nil, "OVERLAY", "GameFontDisable")
  P1.empty:SetPoint("TOP", 0, -110)

  -- ===== Onglet 2 : m'inscrire =====
  P2.me = P2:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  P2.me:SetPoint("TOPLEFT", 6, -4)

  local function lab(text, y)
    local l = P2:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    l:SetPoint("TOPLEFT", 6, y); l:SetText(text)
    return l
  end
  lab("Rôle", -34); lab("Jour", -66); lab("De", -98); lab("à", -98):SetPoint("TOPLEFT", 236, -98)
  lab("Activité", -130); lab("Note", -164)

  local ddRole = dropdown(P2, 160, function(_, root)
    for _, r in ipairs(ROLES) do
      root:CreateRadio(r[2], function() return form.r == r[1] end, function() form.r = r[1] end)
    end
  end, function() return ROLE[form.r] and ROLE[form.r][2] or "Choisir…" end)
  ddRole:SetPoint("TOPLEFT", 90, -28)

  local ddD = dropdown(P2, 160, function(_, root)
    for i = 0, 6 do
      local d = ns.Today(i)
      root:CreateRadio(dayLabel(d), function() return form.d == d end, function() form.d = d end)
    end
  end, function() return form.d and dayLabel(form.d) or "Choisir…" end)
  ddD:SetPoint("TOPLEFT", 90, -60)

  local function hours(key)
    return function(_, root)
      root:SetScrollMode(320)
      for m = 0, 23 * 60 + 30, 30 do
        root:CreateRadio(hm(m), function() return form[key] == m end, function() form[key] = m end)
      end
    end
  end
  local ddH1 = dropdown(P2, 110, hours("h1"), function() return form.h1 and hm(form.h1) or "--:--" end)
  ddH1:SetPoint("TOPLEFT", 90, -92)
  local ddH2 = dropdown(P2, 110, hours("h2"), function() return form.h2 and hm(form.h2) or "--:--" end)
  ddH2:SetPoint("TOPLEFT", 256, -92)

  local ddA = dropdown(P2, 330, function(_, root)
    activityMenu(root, function(id) return form.a == id end, function(id) form.a = id end, false)
  end, function() return form.a and ns.ActName(form.a) or "Choisir un donjon ou des quêtes élites…" end)
  ddA:SetPoint("TOPLEFT", 90, -124)

  local note = CreateFrame("EditBox", "DungeonPlannerNote", P2, "InputBoxTemplate")
  note:SetSize(330, 22); note:SetPoint("TOPLEFT", 96, -158); note:SetAutoFocus(false); note:SetMaxLetters(50)
  note:SetScript("OnEscapePressed", note.ClearFocus); note:SetScript("OnEnterPressed", note.ClearFocus)
  P2.note = note

  local go = CreateFrame("Button", nil, P2, "UIPanelButtonTemplate")
  go:SetSize(150, 26); go:SetPoint("TOPLEFT", 90, -192); go:SetText("M'inscrire")
  P2.msg = P2:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  P2.msg:SetPoint("LEFT", go, "RIGHT", 12, 0)
  go:SetScript("OnClick", function()
    if not ns.Allowed() then P2.msg:SetText("|cffff5555Réservé aux membres de " .. ns.GUILD .. ".|r"); return end
    if not (form.r and form.d and form.h1 and form.h2 and form.a) then
      P2.msg:SetText("|cffff5555Choisis le rôle, le jour, les horaires et l'activité.|r"); return
    end
    local _, cls = UnitClass("player")
    ns.Publish({ c = cls, l = UnitLevel("player"), r = form.r, d = form.d, h1 = form.h1, h2 = form.h2, a = form.a, n = note:GetText() or "" })
    ns.db.last = { r = form.r, h1 = form.h1, h2 = form.h2 }
    note:SetText("")
    P2.msg:SetText("|cff5bd35bC'est noté ! La guilde est prévenue.|r")
  end)

  local mine = P2:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  mine:SetPoint("TOPLEFT", 6, -236); mine:SetText("Mes inscriptions")
  P2.rows = {}
  for i = 1, 6 do
    local r = CreateFrame("Frame", nil, P2); r:SetSize(620, 22); r:SetPoint("TOPLEFT", 6, -236 - i * 24)
    r.t = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); r.t:SetPoint("LEFT", 0, 0); r.t:SetWidth(520); r.t:SetJustifyH("LEFT")
    r.b = CreateFrame("Button", nil, r, "UIPanelButtonTemplate"); r.b:SetSize(80, 20); r.b:SetPoint("RIGHT", 0, 0); r.b:SetText("Retirer")
    P2.rows[i] = r
  end
  P2.more = P2:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")

  P2:SetScript("OnShow", function()
    local last = ns.db.last or {}
    form.r = form.r or last.r
    form.h1 = form.h1 or last.h1
    form.h2 = form.h2 or last.h2
    form.d = form.d or ns.Today()
    P2.msg:SetText("")
    for _, dd in ipairs({ ddRole, ddD, ddH1, ddH2, ddA }) do dd:GenerateMenu() end
  end)
  P1.dds = { ddAct, ddDay }
end

-- ---------- Mise à jour ----------
local function row(i)
  local r = P1.rows[i]
  if r then return r end
  r = CreateFrame("Frame", nil, P1.child)
  r:SetSize(600, 22); r:SetPoint("TOPLEFT", 0, -(i - 1) * 24)
  r:EnableMouse(true)
  local function fs(x, w)
    local s = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    s:SetPoint("LEFT", 8 + x, 0); s:SetWidth(w); s:SetJustifyH("LEFT"); s:SetWordWrap(false)
    return s
  end
  r.name, r.lvl, r.role, r.day, r.hrs, r.act = fs(0, 116), fs(120, 30), fs(152, 50), fs(205, 88), fs(295, 88), fs(385, 120)
  r.mp = CreateFrame("Button", nil, r, "UIPanelButtonTemplate"); r.mp:SetSize(36, 20); r.mp:SetPoint("RIGHT", -44, 0); r.mp:SetText("MP")
  r.inv = CreateFrame("Button", nil, r, "UIPanelButtonTemplate"); r.inv:SetSize(42, 20); r.inv:SetPoint("RIGHT", 0, 0); r.inv:SetText("Inv.")
  r.bg = r:CreateTexture(nil, "BACKGROUND"); r.bg:SetAllPoints(); r.bg:SetColorTexture(1, 1, 1, i % 2 == 0 and 0.04 or 0)
  r:SetScript("OnEnter", function(self)
    local e = self.e; if not e then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:AddLine(short(e.p), classColor(e.c))
    GameTooltip:AddLine(className(e.c) .. " niveau " .. (e.l or "?") .. " – " .. roleText(e.r), 1, 1, 1)
    GameTooltip:AddLine(ns.ActName(e.a), 1, 0.82, 0)
    GameTooltip:AddLine(dayLabel(e.d) .. ", de " .. hm(e.h1) .. " à " .. hm(e.h2), 1, 1, 1)
    if e.n and e.n ~= "" then GameTooltip:AddLine("« " .. e.n .. " »", 0.8, 0.8, 0.8, true) end
    GameTooltip:Show()
  end)
  r:SetScript("OnLeave", function() GameTooltip:Hide() end)
  P1.rows[i] = r
  return r
end

update = function()
  if not F or not F:IsShown() then return end
  F.warn:SetText((ns.Allowed() and (IsInGuild() or not ns.Bypass())) and "" or ns.Bypass() and "Tu n'es dans aucune guilde : tes inscriptions restent sur ton ordinateur." or ("Cet addon est réservé aux membres de la guilde " .. ns.GUILD .. "."))

  if P1:IsShown() then
    for _, dd in ipairs(P1.dds) do if not dd:IsMenuOpen() then dd:GenerateMenu() end end
    local list = ns.List(view.act, view.day)
    local n = { TANK = 0, HEAL = 0, DPS = 0 }
    for _, e in ipairs(list) do n[e.r] = (n[e.r] or 0) + 1 end
    local quand = view.day and dayLabel(view.day) or "cette semaine"
    P1.sum:SetText(ns.ActName(view.act) .. " – " .. quand .. " :  " .. #list .. " inscrit" .. (#list > 1 and "s" or "")
      .. "   |cff4fa3ff" .. n.TANK .. " tank|r · |cff5bd35b" .. n.HEAL .. " soins|r · |cffff6b5b" .. n.DPS .. " dégâts|r")
    for i, e in ipairs(list) do
      local r = row(i)
      r.e = e
      r.name:SetText(short(e.p)); r.name:SetTextColor(classColor(e.c))
      r.lvl:SetText(e.l or "?")
      r.role:SetText(roleText(e.r))
      r.day:SetText(dayLabel(e.d))
      r.hrs:SetText(hm(e.h1) .. " – " .. hm(e.h2))
      local extra = (e.n and e.n ~= "") and e.n or ""
      r.act:SetText(view.act and extra or (ns.ActName(e.a) .. (extra ~= "" and (" · " .. extra) or "")))
      local mine = e.p == ns.me
      r.mp:SetShown(not mine); r.inv:SetShown(not mine)
      r.mp:SetScript("OnClick", function() whisper(e.p) end)
      r.inv:SetScript("OnClick", function() invite(e.p) end)
      r:Show()
    end
    for i = #list + 1, #P1.rows do P1.rows[i]:Hide(); P1.rows[i].e = nil end
    P1.child:SetHeight(math.max(10, #list * 24))
    P1.empty:SetText(#list == 0 and "Personne d'inscrit pour l'instant. Sois le premier : onglet « M'inscrire » !" or "")
  end

  if P2:IsShown() then
    local _, cls = UnitClass("player")
    local r, g, b = classColor(cls)
    P2.me:SetText(string.format("Toi : |cff%02x%02x%02x%s|r – %s niveau %d", r * 255, g * 255, b * 255,
      UnitName("player"), className(cls), UnitLevel("player")))
    local mine = ns.List(nil, nil, true)
    for i, rw in ipairs(P2.rows) do
      local e = mine[i]
      if e then
        rw.t:SetText(dayLabel(e.d) .. ", " .. hm(e.h1) .. " – " .. hm(e.h2) .. " · " .. roleText(e.r) .. " · " .. ns.ActName(e.a)
          .. ((e.n and e.n ~= "") and (" · " .. e.n) or ""))
        rw.b:SetScript("OnClick", function() ns.Remove(e) end)
        rw:Show()
      else
        rw:Hide()
      end
    end
    P2.more:ClearAllPoints()
    P2.more:SetPoint("TOPLEFT", 6, -236 - (math.min(#mine, #P2.rows) + 1) * 24 + 2)
    P2.more:SetText(#mine > #P2.rows and ("… et " .. (#mine - #P2.rows) .. " autre(s), visibles dans l'onglet « Qui est dispo ? »") or
      (#mine == 0 and "Aucune inscription pour l'instant." or ""))
  end
end
ns.UIUpdate = function() update() end

function ns.Toggle()
  if not ns.db then return end
  if not F then build() end
  if F:IsShown() then F:Hide() else F:Show(); update() end
end
