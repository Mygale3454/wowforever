-- Feu de Camp : listes (guilde, activités). Modifie ce fichier pour ajouter un donjon ou une zone.
local ADDON, ns = ...

-- ===== Configuration : version ouverte à toutes les guildes =====
-- Tout le monde peut s'en servir, mais il faut indiquer sa guilde pour s'inscrire.
ns.MODE = "ouvert"
ns.TITRE = "Feu de Camp"
ns.SOUSTITRE = "toutes les guildes"
ns.GUILDES = {}
ns.PREFIX = "FdcP1"
-- Canal de discussion caché partagé par tous les joueurs qui ont l'addon.
ns.CANAL = "FeuDeCampFR"
ns.MDP = "AZxhynem7z95"
ns.SLASH = { "/dispo", "/feudecamp" }
ns.YIELD = "FeuDeCamp_H"   -- si cette version est aussi installée, elle garde /dispo

ns.GUILDESET = {}
for _, g in ipairs(ns.GUILDES) do ns.GUILDESET[g] = true end

-- id court (ne jamais le changer une fois utilisé), nom affiché, niveaux
ns.ACTIVITES = {
  { cat = "Donjons", list = {
    { "ragefeu",   "Gouffre de Ragefeu", "13-18" },
    { "thanes",    "La Salle des Thanes", "13-18" },
    { "lordaeron", "Ruines de Lordaeron", "15-20" },
    { "mortemines","Les Mortemines", "15-22" },
    { "lamentations","Cavernes des lamentations", "17-24" },
    { "ombrecroc", "Donjon d'Ombrecroc", "20-26" },
    { "brassenoire","Profondeurs de Brassenoire", "22-28" },
    { "paluns",    "Site de fouilles des Paluns", "24-29" },
    { "prison",    "La Prison", "25-29" },
    { "dalaran",   "Cité de Dalaran", "28-33" },
    { "gnomeregan","Gnomeregan", "29-38" },
    { "kraal",     "Kraal de Tranchebauge", "29-38" },
    { "me-cim",    "Monastère écarlate : Cimetière", "30-37" },
    { "me-bib",    "Monastère écarlate : Bibliothèque", "33-40" },
    { "me-arm",    "Monastère écarlate : Armurerie", "36-43" },
    { "me-cat",    "Monastère écarlate : Cathédrale", "38-46" },
    { "englo",     "La Cité engloutie", "35-40" },
    { "uldaman",   "Uldaman", "36-45" },
    { "souilles",  "Souilles de Tranchebauge", "37-46" },
    { "krol",      "Bastion de Krol'dok", "40-45" },
    { "zf",        "Zul'Farrak", "40-47" },
    { "maraudon",  "Maraudon", "45-51" },
    { "alcaz",     "Prison d'Alcaz", "48-53" },
    { "temple",    "Temple englouti", "50-55" },
    { "brd",       "Profondeurs de Rochenoire", "52-60" },
    { "noiregueules","Repaire des Noiregueules", "55-60" },
    { "lbrs",      "Pic Rochenoire inférieur", "57-60" },
    { "faconneur", "Terrasse du Façonneur", "58-60" },
    { "ht",        "Hache-Tripes", "58-60" },
    { "strat",     "Stratholme", "58-60" },
    { "scholo",    "Scholomance", "58-60" },
    { "ubrs",      "Pic Rochenoire supérieur", "60" },
  }},
  { cat = "Quêtes élites", list = {
    { "qe-penombre",  "Quêtes élites : Bois de la Pénombre", "25-30" },
    { "qe-paluns",    "Quêtes élites : Les Paluns", "25-30" },
    { "qe-hautebrande","Quêtes élites : Contreforts de Hautebrande", "30-35" },
    { "qe-arathi",    "Quêtes élites : Hautes-terres d'Arathi", "35-40" },
    { "qe-alterac",   "Quêtes élites : Montagnes d'Alterac", "35-40" },
    { "qe-strangle",  "Quêtes élites : Vallée de Strangleronce", "35-45" },
    { "qe-ingrates",  "Quêtes élites : Terres ingrates", "40-45" },
    { "qe-chagrins",  "Quêtes élites : Marais des Chagrins", "40-45" },
    { "qe-feralas",   "Quêtes élites : Féralas", "45-50" },
    { "qe-hinter",    "Quêtes élites : Les Hinterlands", "45-50" },
    { "qe-gangrebois","Quêtes élites : Gangrebois", "50-55" },
    { "qe-steppes",   "Quêtes élites : Steppes ardentes", "55-60" },
    { "qe-maleterres","Quêtes élites : Maleterres", "55-60" },
  }},
  { cat = "XP (montée de niveau)", list = {
    { "xp-elwynn",   "XP : Forêt d'Elwynn", "1-10" },
    { "xp-dunmorogh","XP : Dun Morogh", "1-10" },
    { "xp-teldrassil","XP : Teldrassil", "1-10" },
    { "xp-durotar",  "XP : Durotar", "1-10" },
    { "xp-mulgore",  "XP : Mulgore", "1-10" },
    { "xp-tirisfal", "XP : Clairières de Tirisfal", "1-10" },
    { "xp-marche",   "XP : Marche de l'Ouest", "10-20" },
    { "xp-loch",     "XP : Loch Modan", "10-20" },
    { "xp-sombrivage","XP : Sombrivage", "10-20" },
    { "xp-tarides",  "XP : Les Tarides", "10-25" },
    { "xp-pins",     "XP : Forêt des Pins-Argentés", "10-20" },
    { "xp-carmines", "XP : Les Carmines", "15-25" },
    { "xp-serres",   "XP : Les Serres-Rocheuses", "15-27" },
    { "xp-orneval",  "XP : Orneval", "18-30" },
    { "xp-paluns",   "XP : Les Paluns", "20-30" },
    { "xp-penombre", "XP : Bois de la Pénombre", "18-30" },
    { "xp-hautebrande","XP : Contreforts de Hautebrande", "20-30" },
    { "xp-milles",   "XP : Mille pointes", "25-35" },
    { "xp-arathi",   "XP : Hautes-terres d'Arathi", "30-40" },
    { "xp-alterac",  "XP : Montagnes d'Alterac", "30-40" },
    { "xp-desolace", "XP : Désolace", "30-40" },
    { "xp-aprefange","XP : Marécage d'Âprefange", "35-45" },
    { "xp-strangle", "XP : Vallée de Strangleronce", "30-45" },
    { "xp-ingrates", "XP : Terres ingrates", "35-45" },
    { "xp-chagrins", "XP : Marais des Chagrins", "35-45" },
    { "xp-riverglades","XP : Riverglades", "" },
    { "xp-tanaris",  "XP : Tanaris", "40-50" },
    { "xp-feralas",  "XP : Féralas", "40-50" },
    { "xp-hinter",   "XP : Les Hinterlands", "40-50" },
    { "xp-gorge",    "XP : Gorge des Vents brûlants", "43-50" },
    { "xp-azshara",  "XP : Azshara", "45-55" },
    { "xp-ungoro",   "XP : Cratère d'Un'Goro", "48-55" },
    { "xp-gangrebois","XP : Gangrebois", "48-55" },
    { "xp-foudroyees","XP : Terres foudroyées", "45-55" },
    { "xp-steppes",  "XP : Steppes ardentes", "50-58" },
    { "xp-berceau",  "XP : Berceau-de-l'Hiver", "53-60" },
    { "xp-maleo",    "XP : Maleterres de l'Ouest", "51-58" },
    { "xp-malee",    "XP : Maleterres de l'Est", "53-60" },
    { "xp-silithus", "XP : Silithus", "55-60" },
  }},
  { cat = "Raids", list = {
    { "raid",        "Raid de guilde (dès le 9 décembre)", "60" },
  }},
  { cat = "JcJ", list = {
    { "jcj-goulet",  "JcJ : Goulet des Chanteguerres", "10-60" },
    { "jcj-arathi",  "JcJ : Bassin Arathi", "20-60" },
    { "jcj-alterac", "JcJ : Vallée d'Alterac", "51-60" },
    { "jcj-sauvage", "JcJ : JcJ sauvage", "" },
  }},
  { cat = "Farm", list = {
    { "farm-or",     "Farm : or", "" },
    { "farm-mine",   "Farm : minerai", "" },
    { "farm-herbes", "Farm : herbes", "" },
    { "farm-cuir",   "Farm : cuir et peaux", "" },
    { "farm-tissu",  "Farm : tissu", "" },
    { "farm-rep",    "Farm : réputation", "" },
  }},
  { cat = "Métiers", list = {
    { "met-monter",  "Métiers : monter un métier ensemble", "" },
    { "met-craft",   "Métiers : besoin d'un artisan", "" },
  }},
  { cat = "Autre", list = {
    { "sortie",      "Sortie de guilde", "" },
    { "autre",       "Autre (préciser dans la note)", "" },
  }},
}

ns.ACT = {}
for _, c in ipairs(ns.ACTIVITES) do
  for _, a in ipairs(c.list) do ns.ACT[a[1]] = { name = a[2], lvl = a[3], cat = c.cat } end
end
-- Libellés « tout un menu » pour le filtre de « Qui est dispo ? » (id = "cat:" .. nom du menu).
ns.CATALL = {
  ["Donjons"] = "Tous les donjons", ["Quêtes élites"] = "Toutes les quêtes élites", ["XP (montée de niveau)"] = "Toute l'XP",
  ["Raids"] = "Tous les raids", ["JcJ"] = "Tout le JcJ", ["Farm"] = "Tout le farm", ["Métiers"] = "Tous les métiers", ["Autre"] = "Tout « Autre »",
}
function ns.IsCat(id) return id and id:sub(1, 4) == "cat:" end
function ns.ActName(id)
  if ns.IsCat(id) then local c = id:sub(5); return ns.CATALL[c] or ("Tout : " .. c) end
  local a = id and ns.ACT[id]
  return a and a.name or (id and ("? " .. id) or "Toutes les activités")
end
