-- Feu de Camp : données et échange entre membres de la guilde (canal caché des addons de guilde).
local ADDON, ns = ...

local PREFIX = ns.PREFIX
local SEP = "\t"

ns.relayedAt = {}      -- clé -> GetTime() du dernier relais reçu (pour ne pas relayer deux fois)
ns.lastSeen = {}       -- joueur -> GetTime() de son dernier message (pour savoir qui est connecté)
ns.stats = { sent = 0, recv = 0, err = 0, throttle = 0, rej = {} }
ns.lastQ = {}          -- joueur -> GetTime() de sa dernière demande de synchronisation

-- ---------- Outils ----------
function ns.Today(offset)
  return date("%Y-%m-%d", time() + (offset or 0) * 86400)
end

local function realm()
  local r = GetNormalizedRealmName and GetNormalizedRealmName()
  if r and r ~= "" then return r end
  return nil
end

function ns.Norm(name)
  if not name or name == "" then return nil end
  if not name:find("-", 1, true) then
    local r = realm()
    if r then name = name .. "-" .. r end
  end
  return name
end

function ns.MyName()
  local n, r = UnitFullName("player")
  if not r or r == "" then r = realm() end
  if r then return n .. "-" .. r end
  return n
end

local function split(s)
  local t = {}
  for field in (s .. SEP):gmatch("(.-)" .. SEP) do t[#t + 1] = field end
  return t
end

local function clean(s)
  s = tostring(s or "")
  s = s:gsub("[\t|\r\n]", " ")
  return s
end

local function keyOf(e) return e.p .. "#" .. e.id end
ns.KeyOf = keyOf

-- ---------- Base locale ----------
function ns.InitDB()
  local DBNAME = ADDON .. "DB"            -- même nom que la ligne SavedVariables du .toc
  _G[DBNAME] = _G[DBNAME] or {}
  local db = _G[DBNAME]
  db.entries = db.entries or {}
  db.nextId = db.nextId or 0
  db.last = db.last or {}          -- derniers choix du formulaire
  ns.db = db
  ns.Purge()
end

function ns.Purge()
  local today = ns.Today()
  for k, e in pairs(ns.db.entries) do
    if type(e) ~= "table" or not e.d or e.d < today then ns.db.entries[k] = nil end
  end
end

-- Les personnages dont le nom contient « Araneae » (Mygale) passent outre la restriction de guilde.
local function isAraneae(n) return (n or ""):lower():find("araneae", 1, true) ~= nil end
-- Dans WoW Forever, le nom complet inclut le nom de famille (« Mygale Araneae ») : on vérifie toutes les formes.
function ns.Bypass()
  if isAraneae(UnitName("player")) then return true end
  if GetUnitName and isAraneae(GetUnitName("player", true)) then return true end
  if UnitPVPName and isAraneae(UnitPVPName("player")) then return true end
  return isAraneae(ns.me)
end

function ns.MyGuild()
  return IsInGuild() and GetGuildInfo("player") or ""
end

function ns.Allowed()
  if ns.Bypass() then return true end
  if ns.MODE == "ouvert" then return true end
  return ns.GUILDESET[ns.MyGuild()] == true
end

-- Une inscription reçue est acceptée si elle vient d'une guilde partenaire (ou d'un personnage Araneae).
local function accepted(e)
  if isAraneae(e.p) then return true end
  if ns.MODE == "ouvert" then return (e.g or "") ~= "" end
  return ns.GUILDESET[e.g or ""] == true
end

-- Ajoute ou remplace une inscription reçue ; renvoie true si quelque chose a changé.
-- ---------- Sécurité ----------
local MAX_PAR_JOUEUR = 15       -- inscriptions actives maximum par joueur
local MAX_TOTAL = 3000          -- taille maximum de la base locale
local function countOf(p)
  local n, total = 0, 0
  for _, x in pairs(ns.db.entries) do
    total = total + 1
    if x.p == p and not x.x then n = n + 1 end
  end
  return n, total
end

function ns.Merge(e)
  if e.d < ns.Today() then return false end
  local k = keyOf(e)
  local cur = ns.db.entries[k]
  if cur and (cur.t or 0) >= (e.t or 0) then return false end
  -- un relais ne remplace jamais ce que le joueur a envoyé lui-même
  if cur and cur.src == "d" and e.src ~= "d" then return false end
  if not cur then
    local n, total = countOf(e.p)
    if (not e.x and n >= MAX_PAR_JOUEUR) or total >= MAX_TOTAL then return false end
  end
  ns.db.entries[k] = e
  return true
end

-- Inscriptions visibles (non retirées), filtrées par activité et jour (nil = tout).
local ROLEORDER = { TANK = 1, HEAL = 2, DPS = 3 }
function ns.List(act, day, onlyMine)
  local out, today = {}, ns.Today()
  for _, e in pairs(ns.db.entries) do
    local okAct = not act or e.a == act
    if ns.IsCat(act) then local a = ns.ACT[e.a]; okAct = a ~= nil and ("cat:" .. a.cat) == act end
    if not e.x and e.d >= today and okAct and (not day or e.d == day)
       and (not onlyMine or e.p == ns.me) then
      out[#out + 1] = e
    end
  end
  table.sort(out, function(a, b)
    if a.d ~= b.d then return a.d < b.d end
    if a.h1 ~= b.h1 then return a.h1 < b.h1 end
    local ra, rb = ROLEORDER[a.r] or 9, ROLEORDER[b.r] or 9
    if ra ~= rb then return ra < rb end
    return a.p < b.p
  end)
  return out
end

-- ---------- Messages ----------
local function encode(e)
  return table.concat({ e.id, e.c or "", e.l or 0, e.r or "", e.d, e.h1, e.h2, e.a or "", e.t, e.x and 1 or 0, clean(e.g), clean(e.n) }, SEP)
end

local CLASSES = { WARRIOR = 1, PALADIN = 1, HUNTER = 1, ROGUE = 1, PRIEST = 1, SHAMAN = 1, MAGE = 1, WARLOCK = 1, DRUID = 1 }
local ROLES = { TANK = 1, HEAL = 1, DPS = 1 }

-- Texte reçu : on retire les codes d'interface (|c couleurs, |T images, |H liens…) et on limite la longueur.
local function safe(s, max)
  s = tostring(s or ""):gsub("|", ""):gsub("%c", " ")
  if #s > max then s = s:sub(1, max):gsub("[\192-\255][\128-\191]*$", "") end
  return s
end

local function isInt(v, lo, hi) return v and v == math.floor(v) and v >= lo and v <= hi end

-- Décode ET vérifie une inscription reçue : tout ce qui n'est pas plausible est rejeté.
local function decode(f, i, p)
  if not p or #p > 64 or p:find("|", 1, true) then return nil end
  local e = {
    p = p, id = tonumber(f[i]), c = f[i + 1], l = tonumber(f[i + 2]), r = f[i + 3], d = f[i + 4],
    h1 = tonumber(f[i + 5]), h2 = tonumber(f[i + 6]), a = f[i + 7], t = tonumber(f[i + 8]),
    x = (f[i + 9] == "1") or nil, g = safe(f[i + 10], 48), n = safe(f[i + 11], 120),
  }
  local now = GetServerTime()
  if not (isInt(e.id, 1, 99999) and CLASSES[e.c or ""] and isInt(e.l, 1, 60) and ROLES[e.r or ""]
      and isInt(e.h1, 0, 1410) and isInt(e.h2, 0, 1410) and e.h1 % 30 == 0 and e.h2 % 30 == 0
      and (e.a or ""):match("^[a-z0-9%-]+$") and #e.a <= 24 and e.t and e.t <= now + 300 and e.t >= now - 8 * 86400
      and e.d and e.d:match("^%d%d%d%d%-%d%d%-%d%d$") and e.d >= ns.Today() and e.d <= ns.Today(7)) then
    return nil
  end
  return e
end

-- Anti-flood : un joueur qui envoie trop de messages est ignoré 5 minutes.
local flood = {}
local function flooding(sender)
  local now = GetTime()
  local s = flood[sender]
  if not s or now - s.t0 > 60 then s = { t0 = now, n = 0, ban = s and s.ban or 0 }; flood[sender] = s end
  if s.ban > now then return true end
  s.n = s.n + 1
  if s.n > 75 then s.ban = now + 300; return true end
  return false
end

-- Version réservée : on vérifie dans la liste de la guilde que l'auteur en fait bien partie.
local roster, rosterAt = {}, 0
local function inRoster(name)
  if GetTime() - rosterAt > 60 then
    roster, rosterAt = {}, GetTime()
    local n = GetNumGuildMembers and GetNumGuildMembers() or 0
    for i = 1, n do
      local nm = GetGuildRosterInfo(i)
      if nm then roster[ns.Norm(nm)] = true; roster[ns.Short(nm)] = true end
    end
    roster._n = n
  end
  if (roster._n or 0) == 0 then return true end      -- liste pas encore chargée : on ne bloque pas
  return roster[name] == true or roster[ns.Short(name)] == true
end
local function memberOK(name)
  if ns.MODE ~= "guildes" or #ns.GUILDES ~= 1 then return true end
  return isAraneae(name) or inRoster(name)
end

-- File d'envoi : un message par seconde (limite des messages d'addon).
local queue, ticker = {}, nil
local function pump()
  local m = queue[1]
  if not m then
    if ticker then ticker:Cancel(); ticker = nil end
    return
  end
  if m.relayKey then
    local seen = ns.relayedAt[m.relayKey]
    if seen and seen > m.since then table.remove(queue, 1); return pump() end
  end
  local res = Enum and Enum.SendAddonMessageResult
  local function send(chat, target)
    local okCall, r = pcall(C_ChatInfo.SendAddonMessage, PREFIX, m.msg, chat, target)
    if not okCall then ns.stats.err = ns.stats.err + 1; ns.stats.lastErr = tostring(r); return false end
    if r == false or (type(r) == "number" and res and res.Success and r ~= res.Success) then ns.stats.throttle = ns.stats.throttle + 1; return false end
    return true
  end
  local sentAny = false
  -- 1) canal de la guilde : toujours, si on en a une (le plus fiable entre membres)
  if IsInGuild() then sentAny = send("GUILD") or sentAny end
  -- 2) canal privé : pour joindre les autres guildes (version ouverte ou multi-guildes)
  if ns.UseChannel() then
    local id = GetChannelName(ns.CANAL)
    if id and id > 0 then sentAny = send("CHANNEL", tostring(id)) or sentAny end
  end
  if not sentAny and IsInGuild() and m.tries and m.tries < 3 then m.tries = m.tries + 1; return end  -- on réessaie
  if sentAny then ns.stats.sent = ns.stats.sent + 1 end
  table.remove(queue, 1)
end

local function enqueue(msg, relayKey, since)
  if not ns.Allowed() then return end
  queue[#queue + 1] = { msg = msg, relayKey = relayKey, since = since, tries = 0 }
  if not ticker then
    ticker = C_Timer.NewTicker(1.0, pump)
    pump()
  end
end

local function sendOwn()
  local today = ns.Today()
  for _, e in pairs(ns.db.entries) do
    if e.p == ns.me and e.d >= today then enqueue("E" .. SEP .. encode(e)) end
  end
end

local function onlineSet()
  local s = {}
  local n = GetNumGuildMembers and GetNumGuildMembers() or 0
  for i = 1, n do
    local name, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
    if name and online then s[ns.Norm(name)] = true end
  end
  local now = GetTime()
  for p, t in pairs(ns.lastSeen) do
    if now - t < 900 then s[p] = true end     -- a envoyé un message il y a moins de 15 min
  end
  return s
end

-- Un membre vient de se connecter et demande les dispos : on envoie les nôtres, puis
-- (après un délai au hasard) celles des membres hors ligne qu'on connaît, sauf si un autre l'a déjà fait.
local function onRequest(from)
  sendOwn()
  local since = GetTime()
  C_Timer.After(2 + math.random() * 6, function()
    local online = onlineSet()
    local today = ns.Today()
    for k, e in pairs(ns.db.entries) do
      if e.p ~= ns.me and e.p ~= from and not online[e.p] and e.d >= today then
        enqueue("R" .. SEP .. e.p .. SEP .. encode(e), k, since)
      end
    end
  end)
end

local function rej(why) ns.stats.rej[why] = (ns.stats.rej[why] or 0) + 1 end
local function onMessage(prefix, msg, channel, sender)
  if prefix ~= PREFIX or (channel ~= "GUILD" and channel ~= "CHANNEL") or not ns.db then return end
  ns.stats.lastRaw = sender
  sender = ns.Norm(sender)
  if not sender or sender == ns.me or #msg > 255 then return end
  -- Écho de nos propres messages : le jeu nous renvoie ce qu'on envoie à la guilde, avec notre nom
  -- « officiel » (dans Forever : prénom + nom de famille + royaume). On l'adopte comme identité.
  if msg:sub(1, 2) == "E" .. SEP then
    local f0 = split(msg)
    local id, t0 = tonumber(f0[2]), tonumber(f0[10])
    local own = id and ns.db.entries[ns.me .. "#" .. id]
    if own and own.t == t0 and own.a == f0[9] and own.d == f0[6] then ns.AdoptName(sender); return end
  end
  if ns.myAliases[sender] then return end
  ns.stats.recv = ns.stats.recv + 1
  if flooding(sender) then rej("flood"); return end
  if not memberOK(sender) then rej("membre"); ns.stats.lastRejName = sender; return end
  ns.lastSeen[sender] = GetTime()
  local f = split(msg)
  local kind, e = f[1], nil
  if kind == "E" then
    e = decode(f, 2, sender)
    if e then e.src = "d" end
  elseif kind == "R" then
    local p = ns.Norm(f[2])
    if p == ns.me then return end            -- personne ne parle à notre place
    e = decode(f, 3, p)
    if e then ns.relayedAt[keyOf(e)] = GetTime() end
    -- on n'accepte pas de relais pour un joueur connecté (il envoie lui-même), ni pour un non-membre
    local seen = ns.lastSeen[p]
    if e and ((seen and GetTime() - seen < 900) or not memberOK(p)) then e = nil end
  elseif kind == "Q" then
    local now = GetTime()
    if (ns.lastQ[sender] or 0) > now - 30 or (ns.lastAnyQ or 0) > now - 5 then return end   -- pas plus d'une demande / 30 s
    ns.lastQ[sender], ns.lastAnyQ = now, now
    onRequest(sender)
    return
  end
  if (kind == "E" or kind == "R") and not e then rej("invalide") end
  if e and not accepted(e) then rej("guilde") end
  if e and accepted(e) and ns.Merge(e) then
    ns.Refresh()
    ns.CheckMatch(e)
  end
end

-- Mon identité telle que les autres joueurs la reçoivent (apprise grâce à l'écho de mes messages).
ns.myAliases = {}
function ns.AdoptName(official)
  local old = ns.me
  if not official or official == old then return end
  ns.myAliases[old] = true
  local moved = {}
  for k, e in pairs(ns.db.entries) do
    if e.p == old then moved[#moved + 1] = k end
  end
  for _, k in ipairs(moved) do
    local e = ns.db.entries[k]
    ns.db.entries[k] = nil
    e.p = official
    ns.db.entries[official .. "#" .. e.id] = e      -- remplace aussi le doublon reçu en écho
  end
  ns.me = official
  local guid = UnitGUID and UnitGUID("player")
  if guid then ns.db.meNames = ns.db.meNames or {}; ns.db.meNames[guid] = official end
  ns.Refresh()
end

-- Le canal privé ne sert qu'à joindre d'autres guildes.
function ns.UseChannel()
  return not (ns.MODE == "guildes" and #ns.GUILDES == 1)
end

function ns.Short(name)
  return ((name or ""):match("^[^%- ]+") or ""):lower()
end

-- /dispo debug : tout ce qu'il faut pour comprendre un souci de synchronisation.
function ns.Debug()
  local P = function(s) print("|cffff9933[" .. ns.TITRE .. " debug]|r " .. s) end
  local n1, r1 = UnitFullName("player")
  P("version " .. ((C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(ADDON, "Version")) or "?") .. " · préfixe " .. ns.PREFIX)
  P("moi = " .. tostring(ns.me) .. " · UnitName = " .. tostring(UnitName("player")) .. " · FullName = " .. tostring(n1) .. " / " .. tostring(r1))
  P("guilde = " .. tostring(ns.MyGuild()) .. " · autorisé = " .. tostring(ns.Allowed()) .. " · canal privé = "
    .. (ns.UseChannel() and (ns.CANAL .. " n°" .. tostring(GetChannelName(ns.CANAL))) or "non utilisé"))
  local mine, all = 0, 0
  for _, e in pairs(ns.db.entries) do if not e.x then all = all + 1; if e.p == ns.me then mine = mine + 1 end end end
  P("inscriptions : " .. all .. " dont " .. mine .. " à moi · file d'envoi : " .. #queue)
  local r = {}
  for k, v in pairs(ns.stats.rej) do r[#r + 1] = k .. "=" .. v end
  P("envoyés " .. ns.stats.sent .. " · reçus " .. ns.stats.recv .. " · erreurs " .. ns.stats.err .. " · limités " .. ns.stats.throttle
    .. " · rejetés : " .. (#r > 0 and table.concat(r, " ") or "aucun"))
  if ns.stats.lastRaw then P("dernier expéditeur reçu : " .. tostring(ns.stats.lastRaw)) end
  if ns.stats.lastRejName then P("dernier refusé (membre) : " .. tostring(ns.stats.lastRejName)) end
  if ns.stats.lastErr then P("dernière erreur : " .. ns.stats.lastErr) end
  local nm = GetNumGuildMembers and GetNumGuildMembers() or 0
  P("liste de guilde : " .. nm .. " membres" .. (nm > 0 and (" · ex. " .. tostring((GetGuildRosterInfo(1)))) or ""))
end

-- ---------- Partenaires : qui d'autre est dispo pour mes créneaux ? ----------
local function span(e)
  local s, f = e.h1 or 0, e.h2 or 0
  if f <= s then f = f + 1440 end         -- créneau qui passe minuit
  return s, f
end

-- Deux inscriptions « se recoupent » : même activité, même jour, horaires qui se chevauchent.
function ns.Overlap(a, b)
  if a.a ~= b.a or a.d ~= b.d then return false end
  local s1, f1 = span(a)
  local s2, f2 = span(b)
  return s1 < f2 and s2 < f1
end

-- Les autres joueurs compatibles avec une de mes inscriptions + le décompte des rôles (moi compris).
function ns.Partners(mine)
  local list, n = {}, { TANK = 0, HEAL = 0, DPS = 0 }
  n[mine.r] = (n[mine.r] or 0) + 1
  local seen = {}
  for _, e in pairs(ns.db.entries) do
    if not e.x and e.p ~= ns.me and not seen[e.p] and ns.Overlap(mine, e) then
      seen[e.p] = true
      list[#list + 1] = e
      n[e.r] = (n[e.r] or 0) + 1
    end
  end
  local complete = n.TANK >= 1 and n.HEAL >= 1 and n.DPS >= 3
  return list, n, complete
end

local alerted, completeAlerted = {}, {}
ns.quietUntil = math.huge                 -- pas d'alerte pendant la synchronisation de connexion

local function opts() return ns.db and ns.db.opts or {} end
local function say(msg) print("|cffff9933[" .. ns.TITRE .. "]|r " .. msg) end
local function ding()
  if opts().son ~= false and SOUNDKIT and SOUNDKIT.TELL_MESSAGE then PlaySound(SOUNDKIT.TELL_MESSAGE) end
end

local function who(e)
  local nm = Ambiguate and Ambiguate(e.p, "guild") or e.p
  local cls = (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[e.c or ""]) or e.c or "?"
  local role = ({ TANK = "Tank", HEAL = "Soins", DPS = "Dégâts" })[e.r] or "?"
  return "|cffffffff" .. nm .. "|r (" .. cls .. " " .. (e.l or "?") .. ", " .. role .. ")"
end

-- Appelé quand une inscription d'un autre joueur arrive ou change.
function ns.CheckMatch(e)
  if e.x or e.p == ns.me or opts().alertes == false then return end
  local quiet = GetTime() < ns.quietUntil
  for k, mine in pairs(ns.db.entries) do
    if mine.p == ns.me and not mine.x and ns.Overlap(mine, e) then
      local pair = k .. "|" .. ns.KeyOf(e)
      if not alerted[pair] then
        alerted[pair] = true
        if not quiet then
          say(who(e) .. " est aussi dispo " .. ns.DayLabel(e.d):lower() .. " " .. ns.HM(e.h1) .. "–" .. ns.HM(e.h2)
            .. " pour |cffffd100" .. ns.ActName(e.a) .. "|r. Tape |cffffd100" .. (ns.CMD or "/dispo") .. "|r pour voir.")
          ding()
        end
      end
      local _, n, complete = ns.Partners(mine)
      if complete and not completeAlerted[k] then
        completeAlerted[k] = true
        if not quiet then
          say("|cff5bd35bGroupe complet possible|r pour " .. ns.ActName(mine.a) .. " (" .. ns.DayLabel(mine.d):lower() .. ") : "
            .. n.TANK .. " tank, " .. n.HEAL .. " soins, " .. n.DPS .. " dégâts !")
          ding()
        end
      end
    end
  end
end

-- Après une de mes inscriptions : qui est déjà là ?
function ns.CheckMine(mine)
  if opts().alertes == false then return end
  local list, n, complete = ns.Partners(mine)
  for _, e in ipairs(list) do alerted[ns.KeyOf(mine) .. "|" .. ns.KeyOf(e)] = true end
  if #list > 0 then
    say(#list .. " joueur" .. (#list > 1 and "s sont" or " est") .. " déjà dispo sur ce créneau ("
      .. n.TANK .. " tank, " .. n.HEAL .. " soins, " .. n.DPS .. " dégâts, toi compris)."
      .. (complete and " |cff5bd35bGroupe complet possible !|r" or ""))
    if complete then completeAlerted[ns.KeyOf(mine)] = true end
  end
end

-- Fin de la synchronisation de connexion : un seul résumé au lieu d'une avalanche d'alertes.
function ns.LoginSummary()
  ns.quietUntil = 0
  if opts().alertes == false then return end
  local players, groups = {}, 0
  for k, mine in pairs(ns.db.entries) do
    if mine.p == ns.me and not mine.x and mine.d >= ns.Today() then
      local list, _, complete = ns.Partners(mine)
      for _, e in ipairs(list) do players[e.p] = true; alerted[k .. "|" .. ns.KeyOf(e)] = true end
      if complete then groups = groups + 1; completeAlerted[k] = true end
    end
  end
  local np = 0
  for _ in pairs(players) do np = np + 1 end
  if np > 0 then
    say(np .. " joueur" .. (np > 1 and "s correspondent" or " correspond") .. " à tes inscriptions"
      .. (groups > 0 and (", dont " .. groups .. " groupe" .. (groups > 1 and "s complets" or " complet") .. " possible" .. (groups > 1 and "s" or "")) or "")
      .. ". Tape |cffffd100" .. (ns.CMD or "/dispo") .. "|r pour voir.")
    ding()
  end
end

-- Options : /dispo alertes, /dispo son
function ns.Option(cmd)
  ns.db.opts = ns.db.opts or {}
  local o = ns.db.opts
  if cmd == "alertes" then
    o.alertes = (o.alertes == false)
    say("alertes " .. (o.alertes and "activées" or "désactivées") .. ".")
  elseif cmd == "son" then
    o.son = (o.son == false)
    say("son des alertes " .. (o.son and "activé" or "désactivé") .. ".")
  else
    return false
  end
  return true
end

-- ---------- Actions du joueur ----------
function ns.Publish(e)
  ns.db.nextId = (ns.db.nextId % 99999) + 1
  e.id = e.id or ns.db.nextId
  e.p = ns.me
  e.src = "d"
  if not e.g or e.g == "" then e.g = ns.MyGuild() end
  e.t = GetServerTime()
  local isNew = ns.db.entries[keyOf(e)] == nil
  ns.db.entries[keyOf(e)] = e
  enqueue("E" .. SEP .. encode(e))
  ns.Refresh()
  if isNew then ns.CheckMine(e) end
end

function ns.Remove(e)
  e.x = true
  e.t = GetServerTime()
  enqueue("E" .. SEP .. encode(e))
  ns.Refresh()
end

-- Guildes proposées dans le filtre : la liste fixe, ou (mode ouvert) celles vues dans les inscriptions.
function ns.GuildList()
  if ns.MODE ~= "ouvert" then return ns.GUILDES end
  local seen, out = {}, {}
  for _, e in pairs(ns.db and ns.db.entries or {}) do
    local g = e.g or ""
    if not e.x and g ~= "" and not seen[g] then seen[g] = true; out[#out + 1] = g end
  end
  table.sort(out)
  return out
end

function ns.Refresh()
  if ns.UIUpdate then ns.UIUpdate() end
end

-- ---------- Démarrage ----------
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("PLAYER_LEVEL_UP")
ev:RegisterEvent("PLAYER_GUILD_UPDATE")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")

-- Rejoint le canal privé et le retire des fenêtres de discussion (les joueurs ne le voient pas).
local function hideChannel()
  for i = 1, (NUM_CHAT_WINDOWS or 10) do
    local cf = _G["ChatFrame" .. i]
    if cf then
      if cf.RemoveChannel then pcall(cf.RemoveChannel, cf, ns.CANAL)
      elseif ChatFrame_RemoveChannel then pcall(ChatFrame_RemoveChannel, cf, ns.CANAL) end
    end
  end
end

local function joinChannel(tries)
  if not ns.UseChannel() then return end
  if not ns.Allowed() then          -- infos de guilde pas encore chargées : on réessaie
    if (tries or 0) < 4 then C_Timer.After(10, function() joinChannel((tries or 0) + 1) end) end
    return
  end
  if (GetChannelName(ns.CANAL) or 0) == 0 then
    local join = JoinTemporaryChannel or JoinPermanentChannel
    if join then pcall(join, ns.CANAL, ns.MDP) end
  end
  C_Timer.After(2, function()
    if (GetChannelName(ns.CANAL) or 0) > 0 then
      hideChannel()
    elseif (tries or 0) < 3 then
      C_Timer.After(10, function() joinChannel((tries or 0) + 1) end)
    end
  end)
end
local joined = false
ev:SetScript("OnEvent", function(_, event, ...)
  if event == "PLAYER_LOGIN" then
    ns.InitDB()
    ns.me = ns.MyName()
    local guid = UnitGUID and UnitGUID("player")
    local known = guid and ns.db.meNames and ns.db.meNames[guid]
    if known and known ~= ns.me then ns.AdoptName(known) end
    ns.RegisterSlash()
    C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
    if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end
    C_Timer.After(10, function()
      if ns.Allowed() then
        enqueue("Q")
        sendOwn()
      end
      C_Timer.After(30, ns.LoginSummary)     -- le temps de recevoir les inscriptions des autres
      print("|cffb48cff" .. ns.TITRE .. "|r |cffff9900(bêta)|r : tape |cffffd100" .. (ns.CMD or ns.SLASH[1]) .. "|r pour voir qui est dispo.")
    end)
  elseif event == "CHAT_MSG_ADDON" then
    onMessage(...)
  elseif event == "PLAYER_LEVEL_UP" then
    local lvl = ...
    for _, e in pairs(ns.db.entries) do
      if e.p == ns.me and not e.x then e.l = lvl; ns.Publish(e) end
    end
  elseif event == "PLAYER_GUILD_UPDATE" then
    ns.Refresh()
  elseif event == "PLAYER_ENTERING_WORLD" then
    if not joined then joined = true; C_Timer.After(4, function() joinChannel(0) end) end
  end
end)

-- Commandes. Si les deux versions sont installées, /dispo ouvre Feu de Camp H (la version ouverte garde /feudecamp).
local SLASHKEY = ADDON:upper():gsub("[^A-Z]", "")
local function loaded(name)
  if C_AddOns and C_AddOns.IsAddOnLoaded then return C_AddOns.IsAddOnLoaded(name) end
  return IsAddOnLoaded and IsAddOnLoaded(name)
end
function ns.RegisterSlash()
  local i = 0
  for _, cmd in ipairs(ns.SLASH) do
    if not (ns.YIELD and cmd == "/dispo" and loaded(ns.YIELD)) then
      i = i + 1
      _G["SLASH_" .. SLASHKEY .. i] = cmd
      if i == 1 then ns.CMD = cmd end
    end
  end
end
SlashCmdList[SLASHKEY] = function(msg)
  msg = strtrim((msg or ""):lower())
  if msg == "debug" and ns.db then ns.Debug(); return end
  if msg == "sync" and ns.db then enqueue("Q"); sendOwn(); print("|cffff9933[" .. ns.TITRE .. "]|r synchronisation demandée."); return end
  if msg ~= "" and ns.db and ns.Option(msg) then return end
  if ns.Toggle then ns.Toggle() end
end
